<?php
/**
 * The Headlines Dynamic Styles
 *
 * @package The Headlines
 */

function the_headlines_dynamic_css()
{

    $the_headlines_default = the_headlines_get_default_theme_options();
    $twp_the_headlines_home_sections_4 = get_theme_mod('twp_the_headlines_home_sections_4', json_encode($the_headlines_default['twp_the_headlines_home_sections_4']));
    $twp_the_headlines_home_sections_4 = json_decode($twp_the_headlines_home_sections_4);
    $logo_width_range = get_theme_mod('logo_width_range', $the_headlines_default['logo_width_range']);


    echo "<style type='text/css' media='all'>"; ?>

    <?php

    $repeat_times = 1;

    foreach ($twp_the_headlines_home_sections_4 as $the_headlines_home_section) {

        $section_text_color = esc_url(isset($the_headlines_home_section->section_text_color) ? $the_headlines_home_section->section_text_color : '');

        if ($section_text_color) { ?>

            #theme-block-<?php echo $repeat_times; ?> {
            color: <?php echo esc_url($section_text_color); ?>;
            }

            #theme-block-<?php echo $repeat_times; ?> .news-article-list{
            border-color: <?php echo the_headlines_hex_2_rgba($section_text_color, 0.25); ?>;
            }

            <?php
        }
        $section_background_color = esc_url(isset($the_headlines_home_section->background_color) ? $the_headlines_home_section->background_color : '');

        if ($section_background_color) { ?>

            #theme-block-<?php echo $repeat_times; ?> {
            background-color: <?php echo esc_url($section_background_color); ?>;
            margin-bottom:0;
            }

            <?php
        }

        $background_image = esc_url(isset($the_headlines_home_section->background_image) ? $the_headlines_home_section->background_image : '');

        if ($background_image) {

            $bg_image_size = isset($the_headlines_home_section->bg_image_size) ? $the_headlines_home_section->bg_image_size : 'auto';
            $background_image_repeat = isset($the_headlines_home_section->background_image_repeat) ? $the_headlines_home_section->background_image_repeat : 'yes';
            $background_image_scroll = isset($the_headlines_home_section->background_image_scroll) ? $the_headlines_home_section->background_image_scroll : 'yes';

            if ($background_image_repeat == 'yes' || $background_image_repeat == '') {
                $background_image_repeat = 'repeat';
            } else {
                $background_image_repeat = 'no-repeat';
            }

            if ($background_image_scroll == 'yes' || $background_image_scroll == '') {
                $background_image_scroll = 'scroll';
            } else {
                $background_image_scroll = 'fixed';
            } ?>

            #theme-block-<?php echo $repeat_times; ?> {
            background-image: url(<?php echo esc_url($background_image); ?> );
            background-size: <?php echo esc_attr($bg_image_size); ?>;
            background-repeat: <?php echo esc_attr($background_image_repeat); ?>;
            background-attachment: <?php echo esc_attr($background_image_scroll); ?>;
            }

            <?php
        }

        $repeat_times++;
    } ?>

    .site-logo .custom-logo-link{
    max-width:  <?php echo esc_attr($logo_width_range); ?>px;
    }

    <?php echo "</style>";
}

add_action('wp_head', 'the_headlines_dynamic_css', 100);

/**
 * Sanitizing Hex color function.
 */
function the_headlines_sanitize_hex_color($color)
{

    if ('' === $color)
        return '';
    if (preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color))
        return $color;

}