<?php
/**
 *
 * Front Page
 *
 * @package The Headlines
 */

get_header();


    $the_headlines_default = the_headlines_get_default_theme_options();
    $the_headlines_default = the_headlines_get_default_theme_options();
    $sidebar = esc_attr( get_theme_mod( 'global_sidebar_layout', $the_headlines_default['global_sidebar_layout'] ) );
    

    if( is_single() || is_page() ){

        $the_headlines_post_sidebar = esc_attr( get_post_meta( $post->ID, 'the_headlines_post_sidebar_option', true ) );
        if( $the_headlines_post_sidebar == 'global-sidebar' || empty( $the_headlines_post_sidebar ) ){

            $sidebar = $sidebar;
        }else{
            $sidebar = $the_headlines_post_sidebar;
        }

    }
    $twp_the_headlines_home_sections_4 = get_theme_mod( 'twp_the_headlines_home_sections_4', json_encode( $the_headlines_default['twp_the_headlines_home_sections_4'] ) );
    $repeat_times = 1;
    $paged_active = false;

    if ( !is_paged() ) {
        $paged_active = true;
    }

    $twp_the_headlines_home_sections_4 = json_decode( $twp_the_headlines_home_sections_4 );

    if( $twp_the_headlines_home_sections_4 ){ ?>

        <?php
        foreach ( $twp_the_headlines_home_sections_4 as $the_headlines_home_section ) {

            $home_section_type = isset( $the_headlines_home_section->home_section_type ) ? $the_headlines_home_section->home_section_type : '';

            switch ($home_section_type) {

                case 'main-banner':

                    $ed_slider_blocks = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_slider_blocks == 'yes' && $paged_active ) {
                        the_headlines_main_banner( $the_headlines_home_section , $repeat_times);
                    }

                break;

                case 'latest-posts-blocks':

                    $ed_latest_posts_blocks = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_latest_posts_blocks == 'yes' ) {
                        the_headlines_latest_blocks( $the_headlines_home_section  , $repeat_times);
                    }

                break;

                case 'tiles-blocks':

                    $ed_tiles_block = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_tiles_block == 'yes' && $paged_active ) {
                        the_headlines_tiles_block_section( $the_headlines_home_section , $repeat_times);
                    }

                break;

                case 'banner-blocks-1':

                    $ed_banner_blocks_1 = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_banner_blocks_1 == 'yes' && $paged_active ) {
                        the_headlines_banner_block_1_section( $the_headlines_home_section , $repeat_times);
                    }

                break;

                case 'advertise-blocks':

                    $ed_advertise_blocks = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_advertise_blocks == 'yes' && $paged_active ) {
                        the_headlines_advertise_block( $the_headlines_home_section , $repeat_times);
                    }
                    
                break;

                case 'home-widget-area':

                    $ed_home_widget_area = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_home_widget_area == 'yes' && $paged_active ) {
                        the_headlines_case_home_widget_area_block( $the_headlines_home_section , $repeat_times);
                    }
                    
                break;

                case 'you-may-like-blocks':

                    $ed_you_may_like_area = isset( $the_headlines_home_section->section_ed ) ? $the_headlines_home_section->section_ed : '';
                    if ( $ed_you_may_like_area == 'yes' && $paged_active ) {
                        the_headlines_you_may_like_block_section( $the_headlines_home_section , $repeat_times);
                    }
                    
                break;

                default:

                break;

            }

        $repeat_times++;
        } 
        ?>

    <?php
    }

get_footer();
