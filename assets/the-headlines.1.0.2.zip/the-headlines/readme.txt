== The Headlines ==
Contributors: themeinwp
Requires at least: 5.3
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Headlines is indisputably among the handful one of best WordPress news magazine themes. It boasts a flexible and modern layout that makes it suit any website idea easily. You can use it as easily for news and magazine websites as for blogging purposes. The Headlines is suitable for newspapers, magazine, publishers, blogs, editors, online and gaming magazines, newsportals, personal blogs, newspaper and any other creative website. The Headlines is SEO friendly, WPML,Gutenberg, translation and RTL ready. view demo: https://preview.themeinwp.com/the-headlines/

== Copyright ==

The Headlines WordPress Theme, Copyright 2021 ThemeInWP
The Headlines is distributed under the terms of the GNU GPL.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Credits ==

normalize:
Author: 2012-2015 Nicolas Gallagher and Jonathan Neal
Source: http://necolas.github.io/normalize.css
License: [MIT/GPL2 Licensed](http://opensource.org/licenses/MIT)

BreadcrumbTrail:
Author: Justin Tadlock
Source: http://themehybrid.com/plugins/breadcrumb-trail
License: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Slick carousel:
Author: Ken Wheeler
Source: https://github.com/kenwheeler/slick
License: Licensed under the MIT license

TGM-Plugin-Activation:
Author: Thomas Griffin (thomasgriffinmedia.com)
Source:  https://github.com/TGMPA/TGM-Plugin-Activation
License: GNU General Public License, version 2

Magnific Popup
Author: Chubby Ninja
Source: https://github.com/dimsemenov/Magnific-Popup
License: Licensed under the MIT license

Webfont Loader:
Copyright: Copyright (c) 2020 WPTT
Source: https://github.com/WPTT/webfont-loader
License: Licensed under the MIT license

== Code from Twenty Nineteen ==
Copyright (c) 2018-2019 WordPress.org
License: GPLv2
Source: https://wordpress.org/themes/twentyninteen/
Included as part of the following classes and functions:
- The_Headlines_SVG_Icons

== Image Used ==
Image for theme screenshot, Credit Nature's Beauty
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/peacock-feather-ETZURW3HGP

Copyright Matt Moloney
License: CC0 1.0 Universal (CC0 1.0)
License URL:https://stocksnap.io/license
Source: https://stocksnap.io/photo/woman-portrait-DTLVQXZC5Q

Copyright Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL:https://stocksnap.io/license
Source: https://stocksnap.io/photo/senior-running-PF90KLEZOR

Copyright Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/fitness-male-GPPKPJ32EE

Copyright megapixelstock
License: CC0 1.0 Universal (CC0 1.0)
License URL:https://stocksnap.io/license
Source: https://stocksnap.io/photo/architecture-beach-C5BAW6SFNO

Copyright Matt Bango
License: CC0 1.0 Universal (CC0 1.0)
License URL:https://stocksnap.io/license
Source: https://stocksnap.io/photo/golden-gate-WR2Y6HJMWZ

Copyright PxHere
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1333031

Copyright PxHere
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1062572

Copyright PxHere
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1324391

Copyright PxHere
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/722042

Copyright PxHere
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/629034


== Changelog ==

= 1.0.0 =
* Initial release.

= 1.0.1 =
* Fixed and updated preloader issue

= 1.0.2 =
* Update fixing search and archive title.
