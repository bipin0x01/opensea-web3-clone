<?php
/**
 * The Headlines Theme Customizer
 *
 * @package The Headlines
 */

/** Sanitize Functions. **/
	require get_template_directory() . '/inc/customizer/default.php';

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
if (!function_exists('the_headlines_customize_register')) :

function the_headlines_customize_register( $wp_customize ) {

	require get_template_directory() . '/inc/customizer/active-callback.php';
	require get_template_directory() . '/inc/customizer/custom-classes.php';
	require get_template_directory() . '/inc/customizer/sanitize.php';
	require get_template_directory() . '/inc/customizer/layout.php';
	require get_template_directory() . '/inc/customizer/preloader.php';
	require get_template_directory() . '/inc/customizer/date-ticker-header.php';
	require get_template_directory() . '/inc/customizer/header.php';
	require get_template_directory() . '/inc/customizer/repeater.php';
	require get_template_directory() . '/inc/customizer/pagination.php';
	require get_template_directory() . '/inc/customizer/post.php';
	require get_template_directory() . '/inc/customizer/single.php';
	require get_template_directory() . '/inc/customizer/footer.php';

	$wp_customize->get_section( 'colors' )->panel = 'theme_colors_panel';
	$wp_customize->get_section( 'colors' )->title = esc_html__('Color Options','the-headlines');
	$wp_customize->get_section( 'title_tagline' )->panel = 'theme_general_settings';
	$wp_customize->get_section( 'header_image' )->panel = 'theme_general_settings';
	$wp_customize->get_section( 'background_image' )->panel = 'theme_general_settings';
    

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'the_headlines_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'the_headlines_customize_partial_blogdescription',
		) );
	}
	
	$the_headlines_default = the_headlines_get_default_theme_options();
	$wp_customize->add_setting('logo_width_range',
	    array(
	        'default'           => $the_headlines_default['logo_width_range'],
	        'capability'        => 'edit_theme_options',
	        'sanitize_callback' => 'the_headlines_sanitize_number_range',
	    )
	);
	$wp_customize->add_control('logo_width_range',
	    array(
	        'label'       => esc_html__('Logo With', 'the-headlines'),
	        'description'       => esc_html__( 'Define logo size min-200 to max-700 (step-20)', 'the-headlines' ),
	        'section'     => 'title_tagline',
	        'type'        => 'range',
	        'input_attrs' => array(
				           'min'   => 200,
				           'max'   => 700,
				           'step'   => 20,
			        	),
	    )
	);
	// Theme Options Panel.
	$wp_customize->add_panel( 'theme_option_panel',
		array(
			'title'      => esc_html__( 'Theme Options', 'the-headlines' ),
			'priority'   => 150,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_panel( 'theme_general_settings',
		array(
			'title'      => esc_html__( 'General Settings', 'the-headlines' ),
			'priority'   => 10,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_panel( 'theme_colors_panel',
		array(
			'title'      => esc_html__( 'Color Settings', 'the-headlines' ),
			'priority'   => 15,
			'capability' => 'edit_theme_options',
		)
	);

	// Template Options
	$wp_customize->add_panel( 'theme_template_pannel',
		array(
			'title'      => esc_html__( 'Template Settings', 'the-headlines' ),
			'priority'   => 150,
			'capability' => 'edit_theme_options',
		)
	);

	// Register custom section types.
	$wp_customize->register_section_type( 'The_Headlines_Customize_Section_Upsell' );

	// Register sections.
	$wp_customize->add_section(
		new The_Headlines_Customize_Section_Upsell(
			$wp_customize,
			'theme_upsell',
			array(
				'title'    => esc_html__( 'The Headlines Pro', 'the-headlines' ),
				'pro_text' => esc_html__( 'Upgrade To Pro', 'the-headlines' ),
				'pro_url'  => esc_url('https://www.themeinwp.com/theme/the-headlines-pro/'),
				'priority'  => 1,
			)
		)
	);

}

endif;
add_action( 'customize_register', 'the_headlines_customize_register' );

/**
 * Customizer Enqueue scripts and styles.
 */

if (!function_exists('the_headlines_customizer_scripts')) :

    function the_headlines_customizer_scripts(){   
    	
    	wp_enqueue_script('jquery-ui-button');
    	wp_enqueue_style('the-headlines-customizer', get_template_directory_uri() . '/assets/lib/custom/css/customizer.css');
        wp_enqueue_script('the-headlines-customizer', get_template_directory_uri() . '/assets/lib/custom/js/customizer.js', array('jquery','customize-controls'), '', 1);

        $ajax_nonce = wp_create_nonce('the_headlines_customizer_ajax_nonce');
        wp_localize_script( 
		    'the-headlines-customizer', 
		    'the_headlines_customizer',
		    array(
		        'ajax_url'   => esc_url( admin_url( 'admin-ajax.php' ) ),
		        'ajax_nonce' => $ajax_nonce,
		     )
		);
    }

endif;

add_action('customize_controls_enqueue_scripts', 'the_headlines_customizer_scripts');
add_action('customize_controls_init', 'the_headlines_customizer_scripts');

/**
 * Customizer Enqueue scripts and styles.
 */
function the_headlines_customizer_repearer(){   
	
	wp_enqueue_style('the-headlines-repeater', get_template_directory_uri() . '/assets/lib/custom/css/repeater.css');
    wp_enqueue_script('the-headlines-repeater', get_template_directory_uri() . '/assets/lib/custom/js/repeater.js', array('jquery','customize-controls'), '', 1);

    $the_headlines_post_category_list = the_headlines_post_category_list();

    $cat_option = '';

    if( $the_headlines_post_category_list ){
	    foreach( $the_headlines_post_category_list as $key => $cats ){
	    	$cat_option .= "<option value='". esc_attr( $key )."'>". esc_html( $cats )."</option>";
	    }
	}

    wp_localize_script( 
        'the-headlines-repeater', 
        'the_headlines_repeater',
        array(
            'optionns'   => "
            				<option value='main-banner'>". esc_html__('Main Banner Slider','the-headlines')."</option>
            				<option value='banner-blocks-1'>". esc_html__('Slider & Tab Block','the-headlines')."</option>
            				<option value='latest-posts-blocks'>". esc_html__('Latest Posts Block','the-headlines')."</option>
            				<option selected='selected' value='tiles-blocks'>". esc_html__('Tiles Block','the-headlines')."</option>
        					<option value='advertise-blocks'>". esc_html__('Advertise Block','the-headlines')."</option>
            				<option value='home-widget-area'>". esc_html__('Widgets Area Block','the-headlines')."</option
        					<option value='you-may-like-blocks'>". esc_html__('You May Like Block','the-headlines')."</option>",
           	'categories'   => $cat_option,
            'new_section'   =>  esc_html__('New Section','the-headlines'),
            'upload_image'   =>  esc_html__('Choose Image','the-headlines'),
            'use_image'   =>  esc_html__('Select','the-headlines'),
         )
    );

    wp_localize_script( 
        'the-headlines-customizer', 
        'the_headlines_customizer',
        array(
            'ajax_url'   => esc_url( admin_url( 'admin-ajax.php' ) ),
         )
    );
}

add_action('customize_controls_enqueue_scripts', 'the_headlines_customizer_repearer');

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */

if (!function_exists('the_headlines_customize_partial_blogname')) :

	function the_headlines_customize_partial_blogname() {
		bloginfo( 'name' );
	}
endif;

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */

if (!function_exists('the_headlines_customize_partial_blogdescription')) :

	function the_headlines_customize_partial_blogdescription() {
		bloginfo( 'description' );
	}

endif;

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function the_headlines_customize_preview_js() {
	wp_enqueue_script( 'the-headlines-customizer-preview', get_template_directory_uri() . '/assets/lib/custom/js/customizer-preview.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'the_headlines_customize_preview_js' );