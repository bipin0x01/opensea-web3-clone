<?php
/**
* Sections Repeater Options.
*
* @package The Headlines
*/

$the_headlines_post_category_list = the_headlines_post_category_list();
$the_headlines_defaults = the_headlines_get_default_theme_options();
$home_sections = array(
        
        'main-banner' => esc_html__('Main Banner Slider','the-headlines'),
        'banner-blocks-1' => esc_html__('Slider & Tab Block','the-headlines'),
        'latest-posts-blocks' => esc_html__('Latest Posts Block','the-headlines'),
        'tiles-blocks' => esc_html__('Tiles Block','the-headlines'),
        'advertise-blocks' => esc_html__('Advertise Block','the-headlines'),
        'home-widget-area' => esc_html__('Widgets Area Block','the-headlines'),
        'you-may-like-blocks' => esc_html__('You May Like Block','the-headlines'),

    );

// Slider Section.
$wp_customize->add_section( 'home_sections_repeater',
	array(
	'title'      => esc_html__( 'Homepage Sections', 'the-headlines' ),
	'priority'   => 150,
	'capability' => 'edit_theme_options',
	)
);


// Recommended Posts Enable Disable.
$wp_customize->add_setting( 'twp_the_headlines_home_sections_4', array(
    'sanitize_callback' => 'the_headlines_sanitize_repeater',
    'default' => json_encode( $the_headlines_defaults['twp_the_headlines_home_sections_4'] ),
    // 'transport'           => 'postMessage',
));

$wp_customize->add_control(  new The_Headlines_Repeater_Controler( $wp_customize, 'twp_the_headlines_home_sections_4', 
    array(
        'section' => 'home_sections_repeater',
        'settings' => 'twp_the_headlines_home_sections_4',
        'the_headlines_box_label' => esc_html__('New Section','the-headlines'),
        'the_headlines_box_add_control' => esc_html__('Add New Section','the-headlines'),
        'the_headlines_box_add_button' => false,
    ),
        array(
            'section_ed' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable Section', 'the-headlines' ),
                'class'       => 'home-section-ed'
            ),
            'home_section_type' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Section Type', 'the-headlines' ),
                'options'     => $home_sections,
                'class'       => 'home-section-type'
            ),
            'home_section_title' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Section Title', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs tiles-blocks-fields you-may-like-blocks-fields'
            ),
            'section_slide_category' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Slider Post Category', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs'
            ),
            'section_category' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Post Category', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs tiles-blocks-fields you-may-like-blocks-fields'
            ),
             'tiles_post_per_page' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Posts Per Page', 'the-headlines' ),
                'options'     => array( 
                    '5' => 5,
                    '10' => 10,
                ),
                'class'       => 'home-repeater-fields-hs tiles-blocks-fields'
            ),
             'home_section_column_1' => array(
                  'type'        => 'seperator',
                  'seperator_text'       => esc_html__( 'Column 1', 'the-headlines' ),
                  'class'       => 'home-repeater-fields-hs main-banner-fields'
              ),
              'home_section_title_4' => array(
                 'type'        => 'text',
                 'label'       => esc_html__( 'Block Title', 'the-headlines' ),
                 'class'       => 'home-repeater-fields-hs main-banner-fields'
             ),

              'section_post_cat_1' => array(
                  'type'        => 'select',
                  'label'       => esc_html__( 'Select Category', 'the-headlines' ),
                  'options'     => $the_headlines_post_category_list,
                  'class'       => 'home-repeater-fields-hs main-banner-fields'
              ),
              'home_section_column_2' => array(
                   'type'        => 'seperator',
                   'seperator_text'       => esc_html__( 'Column 2', 'the-headlines' ),
                   'class'       => 'home-repeater-fields-hs main-banner-fields'
               ),
             'home_section_title_1' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Slider Area Title', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields main-banner-fields'
            ),
            'section_post_slide_cat' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Slider Post Category', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields main-banner-fields'
            ),


            'advertise_image' => array(
                'type'        => 'upload',
                'label'       => esc_html__( 'Advertise Image', 'the-headlines' ),
                'description' => esc_html__( 'Recommended Image Size is 970x250 PX.', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs advertise-blocks-fields'
            ),
            'advertise_link' => array(
                'type'        => 'link',
                'label'       => esc_html__( 'Advertise Image Link', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs advertise-blocks-fields'
            ),
            'ed_arrows_carousel' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable Arrows', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields main-banner-fields'
            ),
            'ed_dots_carousel' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable Dot', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields main-banner-fields'
            ),
            'ed_autoplay_carousel' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable Autoplay', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields'
            ),
            'home_section_column_3' => array(
                 'type'        => 'seperator',
                 'seperator_text'       => esc_html__( 'Column 3', 'the-headlines' ),
                 'class'       => 'home-repeater-fields-hs main-banner-fields'
             ),
            'home_section_title_2' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Tab Area Title', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields'
            ),
            'ed_tab' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable Tab', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs ed-tabs-ac banner-blocks-1-fields'
            ),
            'cat_title_1' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Section Title One', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs '
            ),
            'section_category_1' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Post Category One', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields'
            ),
            'cat_title_2' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Section Title Two', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs '
            ),
            'section_category_2' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Post Category Two', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs banner-block-1-tab-ac banner-blocks-1-fields'
            ),
            'cat_title_3' => array(
                'type'        => 'text',
                'label'       => esc_html__( 'Section Title Three', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs '
            ),
            'section_category_3' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Post Category Three', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs banner-block-1-tab-ac banner-blocks-1-fields'
            ),
            'section_category_4' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Post Category Four', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs banner-block-1-tab-ac banner-blocks-1-fields'
            ),
            'section_main_banner_tab_category' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Select Category Tab - 1', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs main-banner-fields'
            ),
            'section_main_banner_tab_category_2' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Select Category Tab - 2', 'the-headlines' ),
                'options'     => $the_headlines_post_category_list,
                'class'       => 'home-repeater-fields-hs main-banner-fields'
            ),
            'ed_flip_column' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Flip Column Right to Left', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs banner-blocks-1-fields'
            ),
            'background_color' => array(
                'type'        => 'colorpicker',
                'label'       => esc_html__( 'Background Color', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields latest-posts-blocks-fields tiles-blocks-fields advertise-blocks-fields you-may-like-blocks-fields'
            ),
            'section_text_color' => array(
                'type'        => 'colorpicker',
                'label'       => esc_html__( 'Text Color', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields latest-posts-blocks-fields tiles-blocks-fields advertise-blocks-fields you-may-like-blocks-fields'
            ),
            'background_image' => array(
                'type'        => 'upload',
                'label'       => esc_html__( 'Background Image', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields tiles-blocks-fields you-may-like-blocks-fields'
            ),
            'bg_image_size' => array(
                'type'        => 'select',
                'label'       => esc_html__( 'Background Image Size', 'the-headlines' ),
                'options'     => array( 
                    'auto' => esc_html('Original','the-headlines'),
                    'contain' => esc_html('Fit to Screen','the-headlines'),
                    'cover' => esc_html('Fill Screen','the-headlines'),
                ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields tiles-blocks-fields you-may-like-blocks-fields'
            ),
            'background_image_repeat' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Repeat Background Image', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields tiles-blocks-fields'
            ),
            'background_image_scroll' => array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Scroll with Page', 'the-headlines' ),
                'class'       => 'home-repeater-fields-hs main-banner-fields banner-blocks-1-fields tiles-blocks-fields you-may-like-blocks-fields'
            ),
    )
));

// Info.
$wp_customize->add_setting(
    'the_headlines_notiece_info',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);
$wp_customize->add_control(
    new The_Headlines_Info_Notiece_Control( 
        $wp_customize,
        'the_headlines_notiece_info',
        array(
            'settings' => 'the_headlines_notiece_info',
            'section'       => 'home_sections_repeater',
            'label'         => esc_html__( 'Info', 'the-headlines' ),
        )
    )
);

$wp_customize->add_setting(
    'the_headlines_premium_notiece',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);
$wp_customize->add_control(
    new The_Headlines_Premium_Notiece_Control( 
        $wp_customize,
        'the_headlines_premium_notiece',
        array(
            'label'      => esc_html__( 'Home Page Blocks', 'the-headlines' ),
            'settings' => 'the_headlines_premium_notiece',
            'section'       => 'home_sections_repeater',
        )
    )
);