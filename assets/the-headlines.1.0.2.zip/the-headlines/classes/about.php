<?php

/**
 * The Headlines About Page
 * @package The Headlines
 *
*/

if( !class_exists('The_Headlines_About_page') ):

	class The_Headlines_About_page{

		function __construct(){

			add_action('admin_menu', array($this, 'the_headlines_backend_menu'),999);

		}

		// Add Backend Menu
        function the_headlines_backend_menu(){

            add_theme_page(esc_html__( 'The Headlines Options','the-headlines' ), esc_html__( 'The Headlines Options','the-headlines' ), 'activate_plugins', 'the-headlines-about', array($this, 'the_headlines_main_page'));

        }

        // Settings Form
        function the_headlines_main_page(){

            require get_template_directory() . '/classes/about-render.php';

        }

	}

	new The_Headlines_About_page();

endif;