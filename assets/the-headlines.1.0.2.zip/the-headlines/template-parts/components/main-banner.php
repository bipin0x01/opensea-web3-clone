<?php
/**
 * Advertise
 *
 * @package The Headlines
 */
if (!function_exists('the_headlines_main_banner')):
    function the_headlines_main_banner($the_headlines_home_section, $repeat_times)
    {
        $section_post_slide_cat = esc_html(isset($the_headlines_home_section->section_post_slide_cat) ? $the_headlines_home_section->section_post_slide_cat : '');
        $section_post_cat_1 = esc_html(isset($the_headlines_home_section->section_post_cat_1) ? $the_headlines_home_section->section_post_cat_1 : '');
        $section_main_banner_tab_category = esc_html(isset($the_headlines_home_section->section_main_banner_tab_category) ? $the_headlines_home_section->section_main_banner_tab_category : '');
        $section_main_banner_tab_category_2 = esc_html(isset($the_headlines_home_section->section_main_banner_tab_category_2) ? $the_headlines_home_section->section_main_banner_tab_category_2 : '');
        $slider_arrows = esc_html(isset($the_headlines_home_section->ed_arrows_carousel) ? $the_headlines_home_section->ed_arrows_carousel : '');
        $slider_dots = esc_html(isset($the_headlines_home_section->ed_dots_carousel) ? $the_headlines_home_section->ed_dots_carousel : '');
        $slider_autoplay = esc_html(isset($the_headlines_home_section->ed_autoplay_carousel) ? $the_headlines_home_section->ed_autoplay_carousel : '');
        $home_section_title_4 = isset($the_headlines_home_section->home_section_title_4) ? $the_headlines_home_section->home_section_title_4 : '';
        $home_section_title_1 = isset($the_headlines_home_section->home_section_title_1) ? $the_headlines_home_section->home_section_title_1 : '';
        if ($slider_arrows == 'yes' || $slider_arrows == '') {
            $arrow = 'true';
        } else {
            $arrow = 'false';
        }
        if ($slider_autoplay == 'yes' || $slider_autoplay == '') {
            $autoplay = 'true';
        } else {
            $autoplay = 'false';
        }
        if ($slider_dots == 'yes') {
            $dots = 'true';
        } else {
            $dots = 'false';
        }
        if (is_rtl()) {
            $rtl = 'true';
        } else {
            $rtl = 'false';
        }
        $banner_query_1 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 2, 'post__not_in' => get_option("sticky_posts"), 'category_name' => esc_html($section_post_cat_1)));
        $banner_query_2 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 5, 'post__not_in' => get_option("sticky_posts"), 'category_name' => esc_html($section_post_slide_cat)));
        if ($section_main_banner_tab_category) {
            $banner_query_3 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 4, 'post__not_in' => get_option("sticky_posts"), 'category_name' => esc_html($section_main_banner_tab_category)));
        } else {
            $section_main_banner_tab_category = esc_html__("Popular", 'the-headlines');
            $banner_query_3 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 4, 'post__not_in' => get_option("sticky_posts"), 'orderby' => 'comment_count'));
        }
        if ($section_main_banner_tab_category_2) {
            $banner_query_4 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 4, 'post__not_in' => get_option("sticky_posts"), 'category_name' => esc_html($section_main_banner_tab_category_2)));
        } else {
            $section_main_banner_tab_category_2 = esc_html__("latest", 'the-headlines');
            $banner_query_4 = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 4, 'post__not_in' => get_option("sticky_posts")));
        } ?>
        <div id="theme-block-<?php echo esc_attr($repeat_times); ?>" class="theme-block theme-main-banner">
            <div class="wrapper">
                <div class="column-row column-row-small">
                    <div class="column column-6 column-md-12 column-sm-12 mb-md-20 column-order-2">
                        <?php if ($banner_query_2->have_posts()): ?>
                            <?php if ($home_section_title_1) { ?>
                                <header class="block-title-wrapper">
                                    <?php if ($home_section_title_1) { ?>
                                        <h2 class="block-title">
                                            <span><?php echo esc_html($home_section_title_1); ?></span>
                                        </h2>
                                    <?php } ?>
                                </header>
                            <?php } ?>
                            <div class="theme-slider-wrapper">
                                <div class="theme-main-slider-block"
                                     data-slick='{"arrows": <?php echo esc_attr($arrow); ?>, "autoplay": <?php echo esc_attr($autoplay); ?>, "dots": <?php echo esc_attr($dots); ?>, "rtl": <?php echo esc_attr($rtl); ?>}'>
                                    <?php
                                    while ($banner_query_2->have_posts()) {
                                        $banner_query_2->the_post();
                                        $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium_large');
                                        $featured_image = isset($featured_image[0]) ? $featured_image[0] : ''; ?>
                                        <div class="theme-slider-item">
                                            <article id="theme-post-<?php the_ID(); ?>" <?php post_class('news-article news-article-panel'); ?>>
                                                <div class="data-bg data-bg-large img-hover-slide" data-background="<?php echo esc_url($featured_image); ?>">
                                                    <?php
                                                    $format = get_post_format(get_the_ID()) ?: 'standard';
                                                    $icon = the_headlines_post_format_icon($format);
                                                    if (!empty($icon)) { ?>
                                                        <span class="top-right-icon">
                                                            <?php echo the_headlines_svg_escape($icon); ?>
                                                        </span>
                                                    <?php } ?>
                                                    <a class="img-link" href="<?php the_permalink(); ?>" tabindex="0"></a>
                                                    <div class="article-content article-content-overlay">
                                                        <div class="entry-meta">
                                                            <?php the_headlines_entry_footer($cats = true, $tags = false, $edits = false, $text = false, $icon = false); ?>
                                                        </div>
                                                        <h2 class="entry-title entry-title-big">
                                                            <a href="<?php the_permalink(); ?>" tabindex="0" rel="bookmark" title="<?php the_title_attribute(); ?>">
                                                                <?php the_title(); ?>
                                                            </a>
                                                        </h2>
                                                        <div class="entry-footer">
                                                            <div class="entry-meta">
                                                                <?php the_headlines_posted_by(); ?>
                                                                <?php the_headlines_post_view_count(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php wp_reset_postdata();
                        endif; ?>
                    </div>
                    <div class="column column-3 column-md-6 column-sm-6 column-xs-12 mb-md-20 column-order-3">
                        <header id="theme-banner-navs">
                            <ul>
                                <li class="active">
                                    <a href="#banner-tab-1">
                                            <span class="banner-navs-icon">
                                            </span>
                                        <span class="banner-navs-"> <?php echo esc_html($section_main_banner_tab_category); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#banner-tab-2">
                                        <?php echo esc_html($section_main_banner_tab_category_2); ?>
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="main-banner-right">
                            <div id="banner-tab-1" class="twp-banner-tab">
                                <?php if ($banner_query_3->have_posts()):
                                    while ($banner_query_3->have_posts()) {
                                        $banner_query_3->the_post();
                                        $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumbnail');
                                        $featured_image = isset($featured_image[0]) ? $featured_image[0] : ''; ?>
                                        <article
                                                id="theme-post-<?php the_ID(); ?>" <?php post_class('news-article news-article-instant'); ?>>
                                            <div class="article-content theme-article-content">
                                                <div class="column-row column-row-small">
                                                    <div class="column column-4">
                                                        <div class="data-bg data-bg-thumbnail" data-background="<?php echo esc_url($featured_image); ?>">
                                                            <?php
                                                            $format = get_post_format(get_the_ID()) ?: 'standard';
                                                            $icon = the_headlines_post_format_icon($format);
                                                            if (!empty($icon)) { ?>
                                                                <span class="top-right-icon">
                                                                    <?php echo the_headlines_svg_escape($icon); ?>
                                                                </span>
                                                            <?php } ?>
                                                            <a class="img-link" href="<?php the_permalink(); ?>" tabindex="0"></a>
                                                        </div>
                                                    </div>
                                                    <div class="column column-8">
                                                        <h3 class="entry-title entry-title-small mb-15">
                                                            <a href="<?php the_permalink(); ?>" tabindex="0" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
                                                        </h3>
                                                        <div class="entry-meta entry-meta-default">
                                                            <?php the_headlines_posted_on($icon = true); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                        <?php
                                    }
                                    wp_reset_postdata();
                                endif; ?>
                            </div>
                            <div id="banner-tab-2" class="twp-banner-tab">
                                <?php if ($banner_query_4->have_posts()): ?>
                                    <?php
                                    while ($banner_query_4->have_posts()) {
                                        $banner_query_4->the_post();
                                        $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumbnail');
                                        $featured_image = isset($featured_image[0]) ? $featured_image[0] : ''; ?>
                                        <article
                                                id="theme-post-<?php the_ID(); ?>" <?php post_class('news-article news-article-instant'); ?>>
                                            <div class="article-content theme-article-content">
                                                <div class="column-row column-row-small">
                                                    <div class="column column-4">
                                                        <div class="data-bg data-bg-thumbnail" data-background="<?php echo esc_url($featured_image); ?>">
                                                            <?php
                                                            $format = get_post_format(get_the_ID()) ?: 'standard';
                                                            $icon = the_headlines_post_format_icon($format);
                                                            if (!empty($icon)) { ?>
                                                                <span class="top-right-icon">
                                                                    <?php echo the_headlines_svg_escape($icon); ?>
                                                                </span>
                                                            <?php } ?>
                                                            <a class="img-link" href="<?php the_permalink(); ?>" tabindex="0"></a>
                                                        </div>
                                                    </div>
                                                    <div class="column column-8">
                                                        <h3 class="entry-title entry-title-small mb-15">
                                                            <a href="<?php the_permalink(); ?>" tabindex="0" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
                                                        </h3>
                                                        <div class="entry-meta entry-meta-default">
                                                            <?php the_headlines_posted_on($icon = true); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                        <?php
                                    } ?>
                                    <?php
                                    wp_reset_postdata();
                                endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($banner_query_1->have_posts()): ?>
                        <div class="column column-3 column-md-6 column-sm-6 column-xs-12 column-order-1">
                            <?php if ($home_section_title_4) { ?>
                                <header class="block-title-wrapper">
                                    <?php if ($home_section_title_4) { ?>
                                        <h2 class="block-title">
                                            <span><?php echo esc_html($home_section_title_4); ?></span>
                                        </h2>
                                    <?php } ?>
                                </header>
                            <?php } ?>
                            <div class="main-banner-left">
                                <?php
                                while ($banner_query_1->have_posts()) {
                                    $banner_query_1->the_post();
                                    $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium_large');
                                    $featured_image = isset($featured_image[0]) ? $featured_image[0] : ''; ?>
                                    <article id="theme-post-<?php the_ID(); ?>" <?php post_class('news-article news-article-panel'); ?>>
                                        <div class="data-bg data-bg-medium img-hover-slide" data-background="<?php echo esc_url($featured_image); ?>">
                                            <?php
                                            $format = get_post_format(get_the_ID()) ?: 'standard';
                                            $icon = the_headlines_post_format_icon($format);
                                            if (!empty($icon)) { ?>
                                                <span class="top-right-icon"><?php echo the_headlines_svg_escape($icon); ?></span>
                                            <?php } ?>
                                            <a class="img-link" href="<?php the_permalink(); ?>" tabindex="0"></a>

                                            <div class="article-content article-content-overlay">
                                                <div class="entry-meta">
                                                    <?php the_headlines_entry_footer($cats = true, $tags = false, $edits = false, $text = false, $icon = false); ?>
                                                </div>
                                                <h3 class="entry-title entry-title-medium">
                                                    <a href="<?php the_permalink(); ?>" tabindex="0" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
                                                </h3>
                                                <div class="entry-meta-wrapper">
                                                    <div class="entry-meta">
                                                        <?php the_headlines_posted_by(); ?>
                                                        <?php the_headlines_post_view_count(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                    <?php
                                } ?>
                            </div>
                        </div>
                        <?php
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
            </div>
        </div>
    <?php }
endif; ?>