<?php
/**
 * Latest Posts
 *
 * @package The Headlines
 */
if( !function_exists('the_headlines_latest_blocks') ):
    
    function the_headlines_latest_blocks($the_headlines_home_section,$repeat_times){

        global $post;
        $the_headlines_default = the_headlines_get_default_theme_options();
        $sidebar = esc_attr( get_theme_mod( 'global_sidebar_layout', $the_headlines_default['global_sidebar_layout'] ) );

        $the_headlines_archive_layout = esc_attr( get_theme_mod( 'the_headlines_archive_layout', $the_headlines_default['the_headlines_archive_layout'] ) ); ?>
        <div id="theme-block-<?php echo esc_attr( $repeat_times ); ?>" class="theme-block theme-block-archive">
            <div class="wrapper">
                <div class="column-row">
                    <div id="primary" class="content-area theme-bottom-sticky">
                        <main id="main" class="site-main" role="main">

                                <?php
                                if( !is_front_page() ) {
                                    the_headlines_breadcrumb_with_title_block();
                                }

                                if( have_posts() ): ?>

                                    <div class="article-wraper archive-layout <?php echo 'archive-layout-' . esc_attr( $the_headlines_archive_layout ); ?>">
                                        <?php while (have_posts()) :
                                            the_post();

                                            if( !is_page() ){

                                                get_template_part( 'template-parts/content', get_post_format() );
                                                
                                            }else{
                                                get_template_part('template-parts/content', 'single');
                                            }


                                        endwhile; ?>
                                    </div>

                                    <?php if( !is_page() ): do_action('the_headlines_archive_pagination'); endif;

                                else :

                                    get_template_part('template-parts/content', 'none');

                                endif; ?>

                        </main><!-- #main -->
                    </div>

                    <?php if( $sidebar != 'no-sidebar' ){

                        get_sidebar();
                        
                    } ?>
                </div>
            </div>
        </div>

    <?php
    }
    
endif;
